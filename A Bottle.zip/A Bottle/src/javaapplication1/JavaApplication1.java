
package javaapplication1;


public class JavaApplication1 {

    public static void main(String[] args) {
   
  
      Butelka [] butelka = new Butelka [10];
  
    int iloscButelek= 0; 
    while (iloscButelek < 10)
    {
        butelka [iloscButelek] = new Butelka ();
        iloscButelek ++ ;
    }
       
   butelka[2].dolej(1000);
    butelka[3].dolej(1);
   butelka[2].wylej(500);
   

   
butelka[2].przelej(100, butelka[3]);
  System.out.println(butelka[3].iloscPlynu);
    }
    
}

 class Butelka
 {
     final int pojemnosc = 1000;
     int iloscPlynu;
     
Butelka()
    {
        
    }
double getIlelitrow ()
    {
    return iloscPlynu;
    }
Butelka(int iloscPlynu)
    {
  
   this.iloscPlynu = iloscPlynu;
    }
boolean dolej (int ilosc)
    {
        if (ilosc + this.iloscPlynu > pojemnosc)
            System.out.println("Za mała pojemnosc butelki");
        else
        iloscPlynu =iloscPlynu+ ilosc;
         System.out.println("W Butelce jest " + iloscPlynu + " płynu." );
         return true;
       
    }
boolean wylej (int wylej)
    {
        if (wylej > this.iloscPlynu)
           System.out.println("Za mało płynu w butelce"); 
        else 
            iloscPlynu = iloscPlynu - wylej;
        System.out.println("W Butelce jest " + iloscPlynu + " płynu." );
        return false;
    }
void przelej (int ilosc , Butelka gdziePrzelac)
    {
      this.wylej(ilosc);
      gdziePrzelac.dolej(ilosc);
       
    }
    
 }